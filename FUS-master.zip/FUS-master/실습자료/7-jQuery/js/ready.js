$( function( ) { 
    alert('jQuery의 세계에 오신 것을 환영합니다.') ;
} ) ; 
