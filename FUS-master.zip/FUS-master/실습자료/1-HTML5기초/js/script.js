 function msg(){
  var str = "자바스크립트에 세계에 오신 것을 환영합니다!" ;
  alert(str) ;
 }
 window.onload = msg ;
